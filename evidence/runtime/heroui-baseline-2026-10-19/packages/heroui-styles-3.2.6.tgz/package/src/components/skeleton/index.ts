export * from "./skeleton.styles";
