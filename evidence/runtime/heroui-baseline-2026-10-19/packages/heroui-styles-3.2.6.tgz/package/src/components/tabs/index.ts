export * from "./tabs.styles";
