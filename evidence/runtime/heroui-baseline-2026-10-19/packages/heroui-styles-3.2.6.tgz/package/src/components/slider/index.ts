export * from "./slider.styles";
