export * from "./avatar.styles";
