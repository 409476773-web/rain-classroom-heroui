export * from "./card.styles";
