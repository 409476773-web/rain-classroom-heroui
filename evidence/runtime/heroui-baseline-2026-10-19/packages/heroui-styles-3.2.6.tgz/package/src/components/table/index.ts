export * from "./table.styles";
