# 雨课堂 HeroUI 主题

适用于本仓库固定的 HeroUI 3.2.6。颜色、字体身份与圆角来自既有雨课堂库；其余样式与交互使用 HeroUI 原版。

在 Tailwind / HeroUI 样式入口后加载：

```css
@import "tailwindcss";
@import "@heroui/styles";
@import "@rain-classroom/heroui-theme";
```

在当前预览文档的 `html` 上使用 `class="light" data-rain-theme="light"`。移除 `data-rain-theme` 即撤销品牌变量；明暗模式由应用自身的主题控制器恢复。不要把根级主题放在组件外的一层普通 div 上，否则 portal 浮层不能可靠继承。不要同时启用其他品牌 preset 或内联颜色覆盖。

文档站和 Storybook 已处理上述切换、清理与明暗模式。常用入口见仓库 `docs/rain/README.md`。

可选关键数字字体：仅给数字及附着西文符号包裹 `<span data-rain-key-data>86.5</span>`，中文单位写在外侧。默认组件、表单和普通正文仍使用 UI 字体。不自动把全部数字换成关键数据字体，不附带字体文件；设备未安装时使用声明的回退字体。

当前雨课堂主题使用 10px 按钮圆角、浅灰蓝空值提示，以及 ListBox 选中项的浅品牌底色。按钮组保留连接处直角；头像、开关等保持原形状。移除主题标记会恢复原版外观。

映射、取舍与检查记录见 `docs/rain/theme-mapping.md`、`docs/rain/theme-acceptance.md` 和 `docs/rain/visual-feedback-2026-10-19.md`。本包目前为本地私有 workspace 包，没有发布。
